#!/usr/bin/env python3
"""
Offshore proxy server (server.py)

- Listens for a single persistent connection from the ship proxy.
- For HTTP requests (MSG_REQUEST): forwards via http.client, sends back MSG_RESPONSE.
- For HTTPS CONNECT requests: establishes upstream socket, enters framed tunnel mode
  using MSG_TUNNEL_DATA / MSG_TUNNEL_CLOSE.
"""

import socket
import threading
import http.client
import urllib.parse
import argparse

BUF = 4096

# Frame message types
MSG_REQUEST = 0
MSG_RESPONSE = 1
MSG_TUNNEL_DATA = 3
MSG_TUNNEL_CLOSE = 4


# ---------------------- framing helpers ----------------------

def recv_all(sock, n):
    data = b""
    while len(data) < n:
        chunk = sock.recv(n - len(data))
        if not chunk:
            raise ConnectionError("socket closed")
        data += chunk
    return data


def read_frame(conn):
    header = conn.recv(5)
    if not header:
        return None, None
    while len(header) < 5:
        header += recv_all(conn, 5 - len(header))
    length = int.from_bytes(header[:4], "big")
    msg_type = header[4]
    payload = recv_all(conn, length) if length > 0 else b""
    return msg_type, payload


def send_frame(conn, msg_type, payload):
    header = len(payload).to_bytes(4, "big") + bytes([msg_type])
    conn.sendall(header + payload)


# ---------------------- HTTP forwarding ----------------------

def forward_http_request(raw_req_bytes):
    """
    Parse a proxy-style raw request and forward via http.client.
    Return raw response bytes.
    """
    try:
        # Split headers and body
        header_end = raw_req_bytes.find(b"\r\n\r\n")
        if header_end == -1:
            headers_block = raw_req_bytes.decode("iso-8859-1")
            body = b""
        else:
            headers_block = raw_req_bytes[:header_end + 4].decode("iso-8859-1")
            body = raw_req_bytes[header_end + 4:]

        # Parse request line
        request_line = headers_block.split("\r\n")[0]
        parts = request_line.split(" ", 2)
        if len(parts) < 2:
            raise ValueError("Invalid request line")
        method = parts[0]
        url = parts[1]

        # Parse URL / host
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme and parsed.hostname:
            hostname = parsed.hostname
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
            path = parsed.path or "/"
            if parsed.query:
                path += "?" + parsed.query
            is_https = (parsed.scheme == "https")
        else:
            # fallback: use Host header
            host = None
            for line in headers_block.split("\r\n")[1:]:
                if line.lower().startswith("host:"):
                    host = line.split(":", 1)[1].strip()
                    break
            if not host:
                raise ValueError("No Host header")
            if ":" in host:
                hostname, port_s = host.split(":", 1)
                port = int(port_s)
            else:
                hostname = host
                port = 80
            path = url if url.startswith("/") else "/"
            is_https = False

        # Open HTTP/HTTPS connection
        if is_https:
            conn = http.client.HTTPSConnection(hostname, port, timeout=15)
        else:
            conn = http.client.HTTPConnection(hostname, port, timeout=15)

        # Build headers dictionary
        headers = {}
        for line in headers_block.split("\r\n")[1:]:
            if not line or ":" not in line:
                continue
            k, v = line.split(":", 1)
            headers[k.strip()] = v.strip()

        # Send upstream request
        conn.request(method, path, body if body else None, headers=headers)
        resp = conn.getresponse()
        resp_body = resp.read()

        # Compose raw HTTP response
        status_line = f"HTTP/1.1 {resp.status} {resp.reason}\r\n".encode("iso-8859-1")
        header_bytes = b"".join(f"{k}: {v}\r\n".encode("iso-8859-1") for k, v in resp.getheaders())
        raw_response = status_line + header_bytes + b"\r\n" + resp_body
        conn.close()
        return raw_response

    except Exception as e:
        err = f"Offshore forward error: {e}".encode("utf-8")
        return (
            b"HTTP/1.1 502 Bad Gateway\r\nContent-Length: "
            + str(len(err)).encode()
            + b"\r\n\r\n"
            + err
        )


# ---------------------- HTTPS tunnel ----------------------

def handle_tunnel_mode(conn, upstream):
    """
    Relay raw bytes between upstream socket and framed connection.
    """
    stop_event = threading.Event()

    def upstream_reader():
        try:
            while not stop_event.is_set():
                data = upstream.recv(BUF)
                if not data:
                    break
                send_frame(conn, MSG_TUNNEL_DATA, data)
        except Exception:
            pass
        finally:
            try:
                send_frame(conn, MSG_TUNNEL_CLOSE, b"")
            except Exception:
                pass
            stop_event.set()

    t = threading.Thread(target=upstream_reader, daemon=True)
    t.start()

    try:
        while not stop_event.is_set():
            msg_type, payload = read_frame(conn)
            if msg_type is None:
                break
            if msg_type == MSG_TUNNEL_DATA:
                if payload:
                    upstream.sendall(payload)
            elif msg_type == MSG_TUNNEL_CLOSE:
                break
    except Exception:
        pass
    finally:
        stop_event.set()
        try:
            upstream.close()
        except:
            pass
        t.join(1)


# ---------------------- main handler ----------------------

def handle_ship_conn(conn, addr):
    print(f"[+] Ship connected from {addr}")
    try:
        while True:
            msg_type, payload = read_frame(conn)
            if msg_type is None:
                break

            if msg_type == MSG_REQUEST:
                # Parse request line
                try:
                    header_block = payload.split(b"\r\n", 1)[0].decode("iso-8859-1")
                    parts = header_block.split(" ", 2)
                    method = parts[0] if parts else None
                    url = parts[1] if len(parts) > 1 else ""
                except Exception:
                    method = None
                    url = None

                if method == "CONNECT":
                    # HTTPS tunnel
                    host, port = (url.split(":", 1) + ["443"])[:2]
                    port = int(port)
                    try:
                        upstream = socket.create_connection((host, port), timeout=15)
                    except Exception:
                        resp = b"HTTP/1.1 502 Bad Gateway\r\nContent-Length:0\r\n\r\n"
                        send_frame(conn, MSG_RESPONSE, resp)
                        continue

                    established = b"HTTP/1.1 200 Connection Established\r\n\r\n"
                    send_frame(conn, MSG_RESPONSE, established)

                    handle_tunnel_mode(conn, upstream)

                else:
                    # Normal HTTP
                    raw_response = forward_http_request(payload)
                    send_frame(conn, MSG_RESPONSE, raw_response)

    except ConnectionError:
        print("[*] Ship connection closed")
    except Exception as e:
        print("Server error:", e)
    finally:
        try:
            conn.close()
        except:
            pass


# ---------------------- entrypoint ----------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind offshore server")
    parser.add_argument("--port", type=int, default=9999, help="Port to listen on")
    args = parser.parse_args()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((args.host, args.port))
    s.listen(1)
    print(f"Offshore proxy listening on {args.host}:{args.port}")

    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_ship_conn, args=(conn, addr), daemon=True).start()


if __name__ == "__main__":
    main()
