#!/usr/bin/env python3
import socket
import threading

MSG_REQUEST = 0
MSG_RESPONSE = 1

def recv_all(sock, n):
    data = b""
    while len(data) < n:
        chunk = sock.recv(n - len(data))
        if not chunk:
            raise ConnectionError("socket closed")
        data += chunk
    return data

def read_frame(conn):
    header = conn.recv(5)
    if not header:
        return None, None
    while len(header) < 5:
        header += recv_all(conn, 5 - len(header))
    length = int.from_bytes(header[:4], "big")
    msg_type = header[4]
    payload = recv_all(conn, length) if length > 0 else b""
    return msg_type, payload

def send_frame(conn, msg_type, payload):
    header = len(payload).to_bytes(4, "big") + bytes([msg_type])
    conn.sendall(header + payload)

def handle_client(client_conn, offshore_host, offshore_port):
    try:
        # Connect to offshore server
        offshore_conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        offshore_conn.connect((offshore_host, offshore_port))
        print(f"[*] Connected to offshore at {offshore_host} {offshore_port}")

        # Peek at first line to check for CONNECT
        request = b""
        client_conn.settimeout(1)
        try:
            while True:
                chunk = client_conn.recv(4096)
                if not chunk:
                    break
                request += chunk
                if b"\r\n\r\n" in request:
                    break
        except socket.timeout:
            pass

        if not request:
            client_conn.close()
            return

        first_line = request.split(b"\r\n", 1)[0].decode("iso-8859-1")
        if first_line.startswith("CONNECT"):
            # Handle HTTPS tunneling
            send_frame(offshore_conn, MSG_REQUEST, request)
            msg_type, payload = read_frame(offshore_conn)
            if msg_type == MSG_RESPONSE:
                client_conn.sendall(payload)  # "200 Connection Established"

            # Relay raw bytes both ways
            def relay(src, dst):
                try:
                    while True:
                        data = src.recv(4096)
                        if not data:
                            break
                        dst.sendall(data)
                except:
                    pass

            t1 = threading.Thread(target=relay, args=(client_conn, offshore_conn))
            t2 = threading.Thread(target=relay, args=(offshore_conn, client_conn))
            t1.start(); t2.start()
            t1.join(); t2.join()
        else:
            # Normal HTTP request
            send_frame(offshore_conn, MSG_REQUEST, request)
            msg_type, payload = read_frame(offshore_conn)
            if msg_type == MSG_RESPONSE:
                client_conn.sendall(payload)

    except Exception as e:
        print("Error in client handler:", e)
    finally:
        client_conn.close()
        offshore_conn.close()

def main(listen_host, listen_port, offshore_host, offshore_port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((listen_host, listen_port))
    s.listen(5)
    print(f"Ship proxy listening on {listen_host}:{listen_port}")
    while True:
        client_conn, addr = s.accept()
        threading.Thread(
            target=handle_client, args=(client_conn, offshore_host, offshore_port), daemon=True
        ).start()

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--listen-host", required=True)
    parser.add_argument("--listen-port", type=int, required=True)
    parser.add_argument("--offshore-host", required=True)
    parser.add_argument("--offshore-port", type=int, required=True)
    args = parser.parse_args()
    main(args.listen_host, args.listen_port, args.offshore_host, args.offshore_port)
